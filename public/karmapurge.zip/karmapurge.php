<?php
require 'config.php';
require_once __DIR__ . '/karmapurge/brain.php';

$key = $_GET['key'] ?? '';
if (!$key || !$karmapurge_api_key) {
    renderErrorPage(400, 'Missing key or API key.');
    exit;
}

$client = new KarmaPurgeClient($karmapurge_api_key);
$response = $client->fetch($key);

if ($response['status'] >= 300 && $response['status'] < 400 && $response['location']) {
    header('Location: ' . $response['location'], true, $response['status']);
    exit;
}

$data = json_decode($response['body'], true);
$code = $response['status'];
$message = $data['error'] ?? 'An unknown error occurred.';

renderErrorPage($code, $message);
exit;

function renderErrorPage(int $code, string $message): void {
    $template = file_get_contents(__DIR__ . '/template/error.html');

    $template = str_replace('{{code}}', htmlspecialchars($code), $template);
    $template = str_replace('{{message}}', htmlspecialchars($message), $template);

    http_response_code($code);
    echo $template;
}
